﻿using System.Text.Json.Serialization;

namespace testePraticoBackEndJoao.Models
{
    public class Post
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Body { get; set; } = string.Empty;
        [JsonIgnore]
        public User User { get; set; }
        public int UserId { get; set; }
        public DateTime CreatedAt { get; set; }
        public ICollection<Tag> Tags { get; set; } = new List<Tag>();
        public ICollection<PostLike> Likes { get; set; } = new List<PostLike>();
        public ICollection<Comment> Comments { get; set; } = new List<Comment>();
    }
}
