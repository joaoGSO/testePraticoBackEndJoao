﻿using Microsoft.EntityFrameworkCore;
using testePraticoBackEndJoao.Models;

namespace testePraticoBackEndJoao.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder mb)
        {
            mb.Entity<User>()
             .HasMany(u => u.Following)
             .WithMany(u => u.Followers)
             .UsingEntity<Dictionary<string, int>>(
                  "UserFollow",
                  j => j.HasOne<User>()
                        .WithMany()
                        .HasForeignKey("FollowedId")
                        .OnDelete(DeleteBehavior.Restrict),
                  j => j.HasOne<User>()
                        .WithMany()
                        .HasForeignKey("FollowerId")
                        .OnDelete(DeleteBehavior.Cascade),
                  j =>
                  {
                      j.HasKey("FollowerId", "FollowedId");
                      j.ToTable("UserFollows");
                  });

            mb.Entity<Post>()
             .HasMany(p => p.Tags)
             .WithMany(t => t.Posts)
             .UsingEntity(j => j.ToTable("PostTags"));

            mb.Entity<PostLike>()
             .HasKey(pl => new { pl.UserId, pl.PostId });

            mb.Entity<PostLike>()
             .HasOne(pl => pl.Post)
             .WithMany(p => p.Likes)
             .HasForeignKey(pl => pl.PostId)
             .OnDelete(DeleteBehavior.Cascade);

            mb.Entity<Comment>()
             .HasOne(c => c.Post)
             .WithMany(p => p.Comments)
             .HasForeignKey(c => c.PostId)
             .OnDelete(DeleteBehavior.Cascade);

            mb.Entity<Post>()
             .HasOne(p => p.User)
             .WithMany(u => u.Posts)
             .HasForeignKey(p => p.UserId)
             .OnDelete(DeleteBehavior.Cascade);

            mb.Entity<Comment>()
             .HasOne(c => c.User)
             .WithMany(u => u.Comments)
             .HasForeignKey(c => c.UserId)
             .OnDelete(DeleteBehavior.NoAction);

            mb.Entity<PostLike>()
             .HasOne(pl => pl.User)
             .WithMany(u => u.LikedPosts)
             .HasForeignKey(pl => pl.UserId)
             .OnDelete(DeleteBehavior.NoAction);
        }

        public DbSet<User> Users { get; set; }

        public DbSet<Post> Posts { get; set; }

        public DbSet<Tag> Tags { get; set; }

        public DbSet<PostLike> PostLikes { get; set; }

        public DbSet<Comment> Comments { get; set; }
    }
}
