﻿using Microsoft.AspNetCore.Mvc;
using testePraticoBackEndJoao.Data;
using testePraticoBackEndJoao.DTO;
using testePraticoBackEndJoao.Models;
using Microsoft.EntityFrameworkCore;

namespace testePraticoBackEndJoao.Controllers
{
    [Route("api/tags")]
    [ApiController]
    public class TagsController : ControllerBase
    {
        private readonly DataContext _context;
        public TagsController(DataContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<ActionResult<Tag>> CreateTag(CreateTagDTO dto)
        {
            var tagName = dto.Name.Trim();
            var existing = await _context.Tags
                              .FirstOrDefaultAsync(t => t.Name.ToLower() == tagName.ToLower());
            if (existing != null) return Conflict("Tag já existe.");

            var tag = new Tag { Name = tagName };
            _context.Tags.Add(tag);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetTagByName), new { name = tag.Name }, tag);
        }

        [HttpGet("{name}")]
        public async Task<ActionResult<Tag>> GetTagByName(string name)
        {
            var tag = await _context.Tags
                      .Include(t => t.Posts)
                      .FirstOrDefaultAsync(t => t.Name.ToLower() == name.ToLower());

            return tag is null ? NotFound() : Ok(tag);
        }
    }
}
