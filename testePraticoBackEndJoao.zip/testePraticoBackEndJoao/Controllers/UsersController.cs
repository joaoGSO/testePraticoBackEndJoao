﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using testePraticoBackEndJoao.Data;
using testePraticoBackEndJoao.DTO;
using testePraticoBackEndJoao.Models;

namespace testePraticoBackEndJoao.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly DataContext _context;

        public UsersController(DataContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<List<User>>> GetUsers()
        {
            var users = await _context.Users
            .Include(u => u.Posts)
            .ToListAsync();

            return users;
        }

        [HttpGet("user")]
        public async Task<ActionResult<List<User>>> GetUserById(int userId)
        {
            var users = await _context.Users
            .Where (u => u.Id == userId)
            .Include(u => u.Posts)
            .ToListAsync();

            return users;
        }

        [HttpPost]
        public async Task<ActionResult<List<User>>> CreateUser(CreateUserDTO request)
        {
            var newUser = new User
            {
                Username = request.Username,
                Email = request.Email
            };

            _context.Users.Add(newUser);
            await _context.SaveChangesAsync();

            return await GetUserById(newUser.Id);
        }

        [HttpPost("{id}/follow/{targetId}")]
        public async Task<IActionResult> Follow(int id, int targetId)
        {
            if (id == targetId)
                return BadRequest("Você não pode seguir a si mesmo.");

            var follower = await _context.Users
                           .Include(u => u.Following)
                           .FirstOrDefaultAsync(u => u.Id == id);

            var followed = await _context.Users.FindAsync(targetId);

            if (follower == null || followed == null)
                return NotFound();

            if (follower.Following.Any(u => u.Id == targetId))
                return Conflict("Você já segue esse usuário.");

            follower.Following.Add(followed);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpDelete("{id}/follow/{targetId}")]
        public async Task<IActionResult> Unfollow(int id, int targetId)
        {
            var follower = await _context.Users
                           .Include(u => u.Following)
                           .FirstOrDefaultAsync(u => u.Id == id);

            if (follower == null)
                return NotFound();

            var followed = follower.Following.FirstOrDefault(u => u.Id == targetId);
            if (followed == null)
                return NotFound();

            follower.Following.Remove(followed);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpGet("{id}/followers")]
        public async Task<ActionResult<IEnumerable<int>>> GetFollowers(int id)
        {
            var user = await _context.Users
                       .Include(u => u.Followers)
                       .FirstOrDefaultAsync(u => u.Id == id);

            return user == null
                   ? NotFound()
                   : Ok(user.Followers.Select(f => f.Id));
        }

        [HttpGet("{id}/following")]
        public async Task<ActionResult<IEnumerable<int>>> GetFollowing(int id)
        {
            var user = await _context.Users
                       .Include(u => u.Following)
                       .FirstOrDefaultAsync(u => u.Id == id);

            return user == null
                   ? NotFound()
                   : Ok(user.Following.Select(f => f.Id));
        }

        [HttpGet("feed/{userId}")]
        public async Task<ActionResult<List<Post>>> GetFeed(int userId)
        {
            bool userExists = await _context.Users.AnyAsync(u => u.Id == userId);
            if (!userExists)
                return NotFound();

            var posts = await _context.Posts
                .Where(p => p.User.Followers.Any(f => f.Id == userId))
                .Include(p => p.User)
                .OrderByDescending(p => p.CreatedAt)
                .ToListAsync();

            return Ok(posts);
        }
    }
}
