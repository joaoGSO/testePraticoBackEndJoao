﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using testePraticoBackEndJoao.Data;
using testePraticoBackEndJoao.DTO;
using testePraticoBackEndJoao.Models;

namespace testePraticoBackEndJoao.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostsController : ControllerBase
    {
        private readonly DataContext _context;
        private static readonly TimeSpan _trendingSpan = TimeSpan.FromHours(24);
        public PostsController(DataContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<List<Post>>> Get(int userId)
        {
            var posts = await _context.Posts
                .Where(x => x.UserId == userId)
                .ToListAsync();

            return posts;
        }

        [HttpPost]
        public async Task<ActionResult<List<Post>>> Create(CreatePostDTO request)
        {
            var user = await _context.Users.FindAsync(request.UserId);
            if (user == null) { return NotFound(); }

            var newPost = new Post
            {
                Title = request.Title,
                Body = request.Body,
                User = user,
                CreatedAt = DateTime.UtcNow
            };

            _context.Posts.Add(newPost);
            await _context.SaveChangesAsync();

            return await Get(newPost.UserId);
        }

        [HttpPost("{postId}/tags")]
        public async Task<IActionResult> AddTagsToPost(int postId, AddTagsToPostDTO dto)
        {
            var post = await _context.Posts
                         .Include(p => p.Tags)
                         .FirstOrDefaultAsync(p => p.Id == postId);

            if (post == null) return NotFound("Post não encontrado.");

            foreach (var raw in dto.Tags)
            {
                var tagName = raw.Trim();
                var tag = await _context.Tags
                            .FirstOrDefaultAsync(t => t.Name.ToLower() == tagName.ToLower())
                          ?? new Tag { Name = tagName };

                if (!post.Tags.Any(t => t.Name.ToLower() == tagName.ToLower()))
                    post.Tags.Add(tag);
            }

            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpGet("bytag/{tagName}")]
        public async Task<ActionResult<IEnumerable<Post>>> GetPostsByTag(string tagName)
        {
            var tag = tagName.Trim();

            var posts = await _context.Posts
                .Where(p => p.Tags.Any(t => t.Name.ToLower() == tag.ToLower()))
                .Include(p => p.User)
                .OrderByDescending(p => p.CreatedAt)
                .ToListAsync();

            return Ok(posts);
        }

        [HttpPost("{postId}/like")]
        public async Task<IActionResult> LikePost(int postId, LikeDTO dto)
        {
            if (dto.Id <= 0) return BadRequest();

            var exists = await _context.PostLikes.FindAsync(dto.Id, postId);
            if (exists != null) return Conflict("Você já curtiu esse post.");

            _context.PostLikes.Add(new PostLike { UserId = dto.Id, PostId = postId });
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{postId}/like/{userId}")]
        public async Task<IActionResult> UnlikePost(int postId, int userId)
        {
            var like = await _context.PostLikes.FindAsync(userId, postId);
            if (like == null) return NotFound();

            _context.PostLikes.Remove(like);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpPost("{postId}/comments")]
        public async Task<IActionResult> AddComment(int postId, CommentDTO dto)
        {
            var user = await _context.Users.FindAsync(dto.Id);
            if (user == null) return NotFound("Usuário inexistente.");

            var post = await _context.Posts.FindAsync(postId);
            if (post == null) return NotFound("Post inexistente.");

            var comment = new Comment
            {
                UserId = dto.Id,
                PostId = postId,
                Text = dto.Text
            };

            _context.Comments.Add(comment);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetComments), new { postId }, comment);
        }

        [HttpGet("{postId}/comments")]
        public async Task<ActionResult<IEnumerable<Comment>>> GetComments(int postId)
        {
            var comments = await _context.Comments
                .Where(c => c.PostId == postId)
                .Include(c => c.User)
                .OrderBy(c => c.CreatedAt)
                .ToListAsync();

            return Ok(comments);
        }

        [HttpGet("trending")]
        public async Task<ActionResult<IEnumerable<object>>> GetTrending()
        {
            var limit = DateTime.UtcNow - _trendingSpan;

            var trending = await _context.PostLikes
                .Where(pl => pl.LikedAt >= limit)
                .GroupBy(pl => pl.PostId)
                .Select(g => new
                {
                    PostId = g.Key,
                    Likes = g.Count(),
                    LastLike = g.Max(pl => pl.LikedAt)
                })
                .OrderByDescending(x => x.Likes)
                .ThenByDescending(x => x.LastLike)
                .Take(20)
                .Join(_context.Posts.Include(p => p.User),
                      g => g.PostId,
                      p => p.Id,
                      (g, p) => new
                      {
                          p.Id,
                          p.Title,
                          p.Body,
                          Author = p.User.Username,
                          g.Likes,
                          g.LastLike
                      })
                .ToListAsync();

            return Ok(trending);
        }

        [HttpPut("{postId}")]
        public async Task<IActionResult> UpdatePost(int postId, UpdatePostDTO dto)
        {
            var post = await _context.Posts.FindAsync(postId);
            if (post == null) return NotFound("Post não encontrado.");

            if (post.UserId != dto.UserId)
                return Forbid();

            if (!string.IsNullOrWhiteSpace(dto.Title))
                post.Title = dto.Title.Trim();

            if (!string.IsNullOrWhiteSpace(dto.Body))
                post.Body = dto.Body.Trim();

            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{postId}")]
        public async Task<IActionResult> DeletePost(int postId, [FromQuery] int userId)
        {
            var post = await _context.Posts.FindAsync(postId);
            if (post == null) return NotFound();

            if (post.UserId != userId)
                return Forbid();

            _context.Posts.Remove(post);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
