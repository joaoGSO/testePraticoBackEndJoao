﻿namespace testePraticoBackEndJoao.DTO
{
    public class UpdatePostDTO
    {
        public string Title { get; set; } = "Title";
        public string Body { get; set; } = "Body";
        public int UserId { get; set; }
    }
}
