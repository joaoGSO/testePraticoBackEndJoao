﻿namespace testePraticoBackEndJoao.DTO
{
    public class CreateUserDTO
    {
        public string Username { get; set; } = "Username";
        public string Email { get; set; } = "Email";
    }
}
