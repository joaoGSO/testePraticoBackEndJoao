﻿namespace testePraticoBackEndJoao.DTO
{
    public class FollowUserDTO
    {
        public int Id { get; set; }
    }
}
