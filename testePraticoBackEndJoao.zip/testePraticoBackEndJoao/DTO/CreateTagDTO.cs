﻿namespace testePraticoBackEndJoao.DTO
{
    public class CreateTagDTO
    {
        public string Name { get; set; } = "Tag";
    }
}
