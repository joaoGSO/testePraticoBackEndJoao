﻿namespace testePraticoBackEndJoao.DTO
{
    public class CreatePostDTO
    {
        public string Title { get; set; } = "Title";
        public string Body { get; set; } = "Body";
        public int UserId { get; set; } = 1;
        public DateTime CreatedAt { get; set; }
    }
}
