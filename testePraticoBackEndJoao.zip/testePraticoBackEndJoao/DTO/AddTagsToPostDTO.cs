﻿namespace testePraticoBackEndJoao.DTO
{
    public class AddTagsToPostDTO
    {
        public List<string> Tags { get; set; }
    }
}
