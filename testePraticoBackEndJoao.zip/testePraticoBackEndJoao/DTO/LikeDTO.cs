﻿namespace testePraticoBackEndJoao.DTO
{
    public class LikeDTO
    {
        public int Id { get; set; }
    }
}
